package com.cg.rms.client;

import java.text.ParseException;

import com.cg.rms.ui.LoginUI;
import com.cg.rms.ui.LoginUIImpl;

public class Client {

	
		public static void main(String args[]) {
			LoginUI client=new LoginUIImpl();
			client.showMenu();
		}	

}
