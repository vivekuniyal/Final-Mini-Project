package com.cg.rms.ui;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

import com.cg.rms.beans.Candidate;
import com.cg.rms.beans.CandidatePersonal;
import com.cg.rms.beans.CandidateQualifications;
import com.cg.rms.beans.CandidateWorkHistory;
import com.cg.rms.beans.JobRequirements;
import com.cg.rms.beans.User;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.CandidateService;
import com.cg.rms.service.CandidateServiceImpl;
import com.cg.rms.service.CompanyService;
import com.cg.rms.service.CompanyServiceImpl;
import com.cg.rms.service.ValidationService;

public class CandidateUIImpl implements CandidateUI{
    Candidate candidate=new Candidate();
    CandidateService candidateService=new CandidateServiceImpl();
    LoginUI loginUI=new LoginUIImpl();
    ValidationService validate=new ValidationService();
    
    @Override
    public void applyJobs(String candidateId) throws RecruitmentException {
        // TODO Auto-generated method stub
        String jobId;
        int flag=0;
        Scanner sc=new Scanner(System.in);
        ArrayList<CandidatePersonal> candidateList=candidateService.viewResume();
        for(CandidatePersonal cPersonal:candidateList)
        {
        if( candidateId.equals(cPersonal.getCandidateId())){
        	flag=1;
        }
        }
        if(flag==0)
        {
        	System.out.println("You need to add your resume first to apply jobs");
        	showCandidateMenu(candidateId);
        }
        if(flag==1){
        ArrayList<JobRequirements>jobReqList=candidateService.getJobRequirements();
        for(JobRequirements jr:jobReqList){
        	System.out.println("\nJob Id:"+jr.getJobId()+"\nCompany Id"+jr.getCompanyId()+"\nPosition Required:"+jr.getPositionRequired()+"\nExperience Required:"+jr.getExperienceRequired()+"\nQualification Required:"+jr.getQualificationRequired()+"\nJob Location:"+jr.getJobLocation());
        }
        System.out.println("Enter Job Id of job you want to apply");
        jobId=sc.next();
        int data=candidateService.applyForJob(jobId, candidateId);
        if(data==1){System.out.println("You have successfully applied ...");}
        else{System.out.println("Unsuccesfull...try again");}}
        else{System.out.println("Unsuccesfull...To search for Jobs First yor need to add your resume");}

    }
    @Override
    public  void searchJobs(String id) throws RecruitmentException {
        // TODO Auto-generated method stub
        String qualification;
        String position;
        int experience;
        String location;
        Scanner sc=new Scanner(System.in);
        try {
			ArrayList<CandidatePersonal> cList=candidateService.viewResume();
			int flag=0;
			for(CandidatePersonal cp:cList)
			{
				if(cp.getCandidateId().equals(id))
				{
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				System.out.println("You need to add your resume first before searching for job  ");
				
				showCandidateMenu(id);
				System.out.println();
				
			}
		} catch (RecruitmentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        System.out.println("Enter your qualification ");
        qualification=sc.next();
        System.out.println("Enter positon to search");
        position=sc.next();
        System.out.println("Enter your experience");
        experience=sc.nextInt();
        System.out.println("Enter prefered location");
        location=sc.next();
        ArrayList<JobRequirements> jobReq=new ArrayList<JobRequirements>();
        jobReq=candidateService.search(qualification, position, experience, location);
        System.out.println("Job Id  Company Id  \t Position Required \t Experience Required \t Qualification Required \t Job Location \tJob Description");
           for(JobRequirements cc:jobReq)
           {
               System.out.println(cc.getJobId()+"   "+cc.getCompanyId()+"\t"+cc.getPositionRequired()+"\t"+cc.getExperienceRequired()+"\t"+cc.getQualificationRequired()+"\t"+cc.getJobLocation()+"\t"+cc.getJobDescription());
           }
    }
    @Override
    public  void modifyResume(String id)  {
        // TODO Auto-generated method stub
    	 Candidate candidate;
        Scanner sc=new Scanner(System.in);
        
        //String candidateId;
        String candidateName;
        String address;
        LocalDate dob;
        String emailId;
        String contactNumber;
        String maritalStatus;
        String gender;
        String passportNumber;

        String qualificationId;
        String qualificationName;
        String specializationArea;
        String collegeName;
        String universityName;
        String yearOfpassing;
        double percentage;

        String workId;
        String whichEmployer;
        String contactPerson;
        String positionHeld;
        String companyName;
        LocalDate employmentFrom;
        LocalDate employmentTo;
        String reasonForLeaving;
        String responsibilities;
        String hrRepName;
        String hrRepContactNum;
        
        try {
			ArrayList<CandidatePersonal> cList=candidateService.viewResume();
			int flag=0;
			for(CandidatePersonal cp:cList)
			{
				if(cp.getCandidateId().equals(id))
				{
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				System.out.println("You need to add your resume first before modifying  ");
				
				showCandidateMenu(id);
				System.out.println();
				
			}
		} catch (RecruitmentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
        
        
        
        System.out.println("----------------------Enter the Details to Modify------------------");
        System.out.println();
        System.out.println("Enter your Personal Details....");
        while(true)
        {
        	try {
        		System.out.println("Enter candidate name");
        		candidateName=sc.next();
        		if(validate.validateUserName(candidateName))
        		{
        			break;
        		}
        	}
        	catch (RecruitmentException e) {

        		System.out.println(e.getMessage());
        	}
        }
        
			System.out.println("Enter address");
			address=sc.next();
			System.out.println("Enter date of birth");
			DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter date in dd/MM/yyyy format:");
			String input=scanner.next();
			dob=LocalDate.parse(input,formatter);
			while(true)
			{
			System.out.println("Enter email id");
			emailId=sc.next();
			try
			{
				if(validate.validateEmail(emailId))
				{
					break;
				}
			}
			catch(RecruitmentException e)
			{
				System.out.println(e.getMessage());
			}
			}
			while(true)
			{
			System.out.println("Enter contact number");
			contactNumber=sc.next();
			try{
				if(validate.validatePhone(contactNumber))
					break;
			}
			catch(RecruitmentException e)
			{
				System.out.println(e.getMessage());
			}
			}
				
			
			System.out.println("Enter marital status");
			maritalStatus=sc.next();
			System.out.println("Enter gender (M/F)");
			gender=sc.next();
			System.out.println("Enter passport number");
			passportNumber=sc.next();
			
			CandidatePersonal personal=new CandidatePersonal(id,candidateName,address,dob,emailId,contactNumber,maritalStatus,gender,passportNumber);
			// candidate.setCandidatePersonal(new CandidatePersonal(candidateName,address,dob1,emailId,contactNumber,maritalStatus,gender,passportNumber));
			
			System.out.println("Enter your educational qualifications....");
			System.out.println("Enter qualificaion name");
			qualificationName=sc.next();
			System.out.println("Enter Specialization Area");
			specializationArea=sc.next();
			System.out.println("Enter College name");
			collegeName=sc.next();
			System.out.println("Enter university name");
			universityName=sc.next();
			System.out.println("Enter year of passing");
			yearOfpassing=sc.next();
			System.out.println("Enter percentage");
			percentage=sc.nextDouble();
			//candidate.setCandidateQualifications(new CandidateQualifications(qualificationId,qualificationName,specializationArea,collegeName,universityName,yearOfpassing,percentage));
			CandidateQualifications qualifications=new CandidateQualifications(qualificationName,specializationArea,collegeName,universityName,yearOfpassing,percentage,id);
			System.out.println("Are you fresher? Enter Yes/No");
			String expChoice=sc.next();
			if(expChoice.equals("No"))
			{
				System.out.println();
			System.out.println("Enter Work Experience Details....");
			System.out.println();
			System.out.println("Enter Employer name");
			whichEmployer=sc.next();
			System.out.println("Enter contact person");
			contactPerson=sc.next();
			System.out.println("Enter position held");
			positionHeld=sc.next();
			System.out.println("Enter company name");
			companyName=sc.next();
			System.out.println("Enter your Previous Work ID:");
			workId=sc.next();
			System.out.println("Enter employment from (dd/mm/yyyy)");
			String empFrom=sc.next();
			DateTimeFormatter format1= DateTimeFormatter.ofPattern("dd/MM/yyyy");
			employmentFrom=LocalDate.parse(empFrom,format1);
			System.out.println("Enter employment upto (dd/mm/yyyy)");
			String empTo=sc.next();
			DateTimeFormatter format2= DateTimeFormatter.ofPattern("dd/MM/yyyy");
			employmentTo=LocalDate.parse(empTo,format2);
			System.out.println("Enter reason for leaving");
			reasonForLeaving=sc.next();
			System.out.println("Enter responsibilities");
			responsibilities=sc.next();
			System.out.println("Enter HR representative name");
			hrRepName=sc.next();
			System.out.println("Enter HR representative contact number");
			hrRepContactNum=sc.next();
			//candidate.setCandidateWorkHistory(new CandidateWorkHistory(workId,whichEmployer,contactPerson,positionHeld,companyName,employmentFrom,employmentTo,reasonForLeaving,responsibilities,hrRepName,hrRepContactNum));
			CandidateWorkHistory workHistory=new CandidateWorkHistory(workId,id,whichEmployer,contactPerson,positionHeld,companyName,employmentFrom,employmentTo,reasonForLeaving,responsibilities,hrRepName,hrRepContactNum);
     candidate=new Candidate(personal,qualifications,workHistory);
			}
			
			else
			{
			    CandidateWorkHistory workHistory=new CandidateWorkHistory();
			    workHistory=null;
			    candidate=new Candidate(personal,qualifications,workHistory);
			    
			   
			}
			int data=0;
			try {
				data = candidateService.modifyResume(candidate,id);
			} catch (RecruitmentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("=============================================");
			if(data==3||data==2){
			    System.out.println("Resume Modified Successfully for "+candidateName);
			}else{
			    System.out.println("Resume  could not be Modified. Try again later");
			}
			System.out.println("=============================================");
			

			
			
		}

    
    @Override
    public void addResume(String id)  {
        Scanner sc=new Scanner(System.in);
        Candidate candidate;
        String candidateName;
        String address;
        LocalDate dob;
        String emailId;
        String contactNumber;
        String maritalStatus;
        String gender;
        String passportNumber;

        String qualificationId;
        String qualificationName;
        String specializationArea;
        String collegeName;
        String universityName;
        String yearOfpassing;
        double percentage;

        String workId;
        String whichEmployer;
        String contactPerson;
        String positionHeld;
        String companyName;
        LocalDate employmentFrom;
        LocalDate employmentTo;
        String reasonForLeaving;
        String responsibilities;
        String hrRepName;
        String hrRepContactNum;
        //Candidate candidate=new Candidate();
        
        ArrayList<CandidatePersonal> cList;
		try {
			cList = candidateService.viewResume();
			for(CandidatePersonal cp:cList)
			{
				if(cp.getCandidateId().equals(id))
						{
							System.out.println("Your resume is already exist with Id:- "+id);
							System.out.println("Kindly choose any other option");
							showCandidateMenu(id);
						}
			}
		} catch (RecruitmentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
        
        
        try{
            System.out.println("Enter your personal details....");
            while(true)
            {
            	try {
            		System.out.println("Enter candidate name");
            		candidateName=sc.next();
            		if(validate.validateUserName(candidateName))
            		{
            			break;
            		}
            	}
            	catch (RecruitmentException e) {

            		System.out.println(e.getMessage());
            	}
            }
            
            System.out.println("Enter address");
            address=sc.next();
            System.out.println("Enter date of birth");
       			DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
    			Scanner scanner=new Scanner(System.in);
    			System.out.println("Enter date in dd/MM/yyyy format:");
    			String input=scanner.next();
    			dob=LocalDate.parse(input,formatter);
    			//System.out.println("Entered Date:"+ enteredDate);
    			//scanner.close();
    			while(true)
    			{
    			System.out.println("Enter email id");
    			emailId=sc.next();
    			try
    			{
    				if(validate.validateEmail(emailId))
    				{
    					break;
    				}
    			}
    			catch(RecruitmentException e)
    			{
    				System.out.println(e.getMessage());
    			}
    			}
    			while(true)
    			{
    			System.out.println("Enter contact number");
    			contactNumber=sc.next();
    			try{
    				if(validate.validatePhone(contactNumber))
    					break;
    			}
    			catch(RecruitmentException e)
    			{
    				System.out.println(e.getMessage());
    			}
    			}
            
            System.out.println("Enter marital status");
            maritalStatus=sc.next();
            System.out.println("Enter gender");
            gender=sc.next();
            System.out.println("Enter passport number");
            passportNumber=sc.next();
            
            
            //personal information retrieve successfully
            
            
            
            CandidatePersonal personal=new CandidatePersonal(id,candidateName,address,dob,emailId,contactNumber,maritalStatus,gender,passportNumber);
            System.out.println();
            System.out.println("Enter your educational qualifications....");
            System.out.println();
            System.out.println("Enter qualification name");
            qualificationName=sc.next();
            System.out.println("Enter Specialization Area");
            specializationArea=sc.next();
            System.out.println("Enter College name");
            collegeName=sc.next();
            System.out.println("Enter university name");
            universityName=sc.next();
            System.out.println("Enter year of passing");
            yearOfpassing=sc.next();
            System.out.println("Enter percentage");
            percentage=sc.nextDouble();
            //candidate.setCandidateQualifications(new CandidateQualifications(qualificationId,qualificationName,specializationArea,collegeName,universityName,yearOfpassing,percentage));
            
            CandidateQualifications qualifications=new CandidateQualifications(qualificationName,specializationArea,collegeName,universityName,yearOfpassing,percentage,id);
            System.out.println("Are you fresher? Enter Yes/No");
            String expChoice=sc.next();
            if(expChoice.equals("No"))
            {
            System.out.println("Enter work experience details....");
            System.out.println("Enter work ID");
            workId=sc.next();
            System.out.println("Enter Employer name");
            whichEmployer=sc.next();
            System.out.println("Enter contact person");
            contactPerson=sc.next();
            System.out.println("Enter position held");
            positionHeld=sc.next();
            System.out.println("Enter company name");
            companyName=sc.next();
            System.out.println("Enter employment from in dd/mm/yyyy pattern");
            String empFrom=sc.next();
            DateTimeFormatter format1= DateTimeFormatter.ofPattern("dd/MM/yyyy");
            employmentFrom=LocalDate.parse(empFrom,format1);
            System.out.println("Enter empoyment to in dd/mm/yyyy pattern");
            String empTo=sc.next();
            DateTimeFormatter format2= DateTimeFormatter.ofPattern("dd/MM/yyyy");
            employmentTo=LocalDate.parse(empTo,format2);
            System.out.println("Enter reason for leaving");
            reasonForLeaving=sc.next();
            System.out.println("Enter responsibilities");
            responsibilities=sc.next();
            System.out.println("Enter hr representative name");
            hrRepName=sc.next();
            System.out.println("Enter hr representative contact number");
            hrRepContactNum=sc.next();
            //candidate.setCandidateWorkHistory(new CandidateWorkHistory(workId,whichEmployer,contactPerson,positionHeld,companyName,employmentFrom,employmentTo,reasonForLeaving,responsibilities,hrRepName,hrRepContactNum));
            CandidateWorkHistory workHistory=new CandidateWorkHistory(workId,id,whichEmployer,contactPerson,positionHeld,companyName,employmentFrom,employmentTo,reasonForLeaving,responsibilities,hrRepName,hrRepContactNum);
            candidate=new Candidate(personal,qualifications,workHistory);
           
            }
            else{
                CandidateWorkHistory workHistory=new CandidateWorkHistory();
                workHistory=null;
                
                candidate=new Candidate(personal,qualifications,workHistory);
                
               
            }
            
            System.out.println("=============================================");
            int data=candidateService.addResume(candidate);
            if(data==-1)
            {
            	System.out.println("Resume already exist with Id:- "+id);
            }
           
            if(data==3||data==2){
            System.out.println("Resume added with id....."+id);
        }else{
            System.out.println("Resume  could not be added.....");
        }
            System.out.println("=============================================");
        
            
            
        }
        
        catch (RecruitmentException e) {
            // TODO Auto-generated catch block
            System.out.println(e.getMessage());
            showCandidateMenu(id);
        }
            


    }
    @Override
    public  void showCandidateMenu(String id) 
    {
    	System.out.println("=================================");
    	System.out.println("        Candidate User Menu");
    	System.out.println("=================================");
        System.out.println(" 1:Add resume  \n "
                + "2:Modify resume \n "
                + "3:Search for jobs based on qualification, position, years of experience,location\n"+
                " 4:Apply for jobs\n" +" 5:Logout");
        System.out.println("Enter ur choice");
        Scanner sc=new Scanner(System.in);
        int ch=sc.nextInt();
        switch(ch){
        
        case 1:addResume(id);break;
        case 2:modifyResume(id);break;
        case 4:try {
				applyJobs(id);
			} catch (RecruitmentException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}break;
        case 3:try {
				searchJobs(id);
			} catch (RecruitmentException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
				
			}break;
        case 5:System.out.println("You have Successfully signed out");loginUI.showMenu();break;
    default:System.out.println("Invalid choice");

        }
        showCandidateMenu(id);
        
    }

}