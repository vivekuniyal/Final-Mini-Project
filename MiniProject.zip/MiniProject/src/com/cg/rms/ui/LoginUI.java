package com.cg.rms.ui;

import java.text.ParseException;

public interface LoginUI {
	public void login() throws ParseException;
	public void showMenu() ;
	public void signUp() throws ParseException;;
}
