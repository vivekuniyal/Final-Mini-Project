package com.cg.rms.junit;


import java.sql.Date;
import java.time.LocalDate;
import java.time.Month;

import org.junit.Assert;
import org.junit.Test;

import com.cg.rms.beans.Candidate;
import com.cg.rms.beans.CandidatePersonal;
import com.cg.rms.beans.CandidateQualifications;
import com.cg.rms.beans.CandidateWorkHistory;
import com.cg.rms.beans.CompanyMaster;
import com.cg.rms.beans.JobApplied;
import com.cg.rms.beans.JobRequirements;
import com.cg.rms.dao.CandidateDAOImpl;
import com.cg.rms.dao.CompanyUserDAOImpl;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.ValidationService;

public class TestRecruitment {
    

    CandidateDAOImpl candDaoImpl=new CandidateDAOImpl();
    CompanyUserDAOImpl compDaoImpl=new CompanyUserDAOImpl();
    ValidationService validate=new ValidationService();
    
  
    
        
   
    @Test
    public void testApplyForJobs() throws RecruitmentException
    {
        //JobApplied jobApplied=new JobApplied("111","111");        
        Assert.assertEquals(1,candDaoImpl.applyForJob("9856","111"));
        
    }
    
    @Test(expected=RecruitmentException.class)
    public void validateName() throws RecruitmentException 
    {
        //JobApplied jobApplied=new JobApplied("111","111");        
        Assert.assertEquals(true,validate.validateUserName("Rahul"));
     
        Assert.assertEquals(1,validate.validateUserName("123"));
    
    }
    @Test(expected=RecruitmentException.class)
    public void validateEmail() throws RecruitmentException 
    {
    	 Assert.assertEquals(true,validate.validateEmail("Rahul@gmail.com"));
         
         Assert.assertEquals(1,validate.validateUserName("123.sd"));
    }
    @Test(expected=RecruitmentException.class)
    public void validatePhone() throws RecruitmentException 
    {
    	 Assert.assertEquals(true,validate.validatePhone("9874563210"));
         
         Assert.assertEquals(1,validate.validatePhone("09876"));
    }

   
}
